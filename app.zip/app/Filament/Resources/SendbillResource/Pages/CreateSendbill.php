<?php

namespace App\Filament\Resources\SendbillResource\Pages;

use App\Filament\Resources\SendbillResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSendbill extends CreateRecord
{
    protected static string $resource = SendbillResource::class;
}
